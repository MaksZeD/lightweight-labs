package edu.rad.lab1.repository;
/*
  @author   max
  @project   lab1
  @class  StudentRepository
  @version  1.0.0
  @since 23.02.24 - 17.42
*/

import edu.rad.lab1.model.Student;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentRepository extends MongoRepository<Student, String> {
}
