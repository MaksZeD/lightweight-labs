package edu.rad.lab1.exception;
/*
  @author   max
  @project   lab1
  @class  IdentifierMismatchException
  @version  1.0.0
  @since 23.02.24 - 17.42
*/

public class IdentifierMismatchException extends Exception {
    public IdentifierMismatchException(String s) {
        super(s);
    }
}
