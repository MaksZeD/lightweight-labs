package edu.rad.lab1.dto;
/*
  @author   max
  @project   lab1
  @class  Response
  @version  1.0.0
  @since 23.02.24 - 17.42
*/

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Response {
    private String message;
}
