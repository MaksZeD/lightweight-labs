package edu.rad.lab1.service;
/*
  @author   max
  @project   lab1
  @class  StudentService
  @version  1.0.0
  @since 23.02.24 - 17.42
*/

import edu.rad.lab1.repository.StudentRepository;
import edu.rad.lab1.model.Student;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;

@Service
@Slf4j
@RequiredArgsConstructor
public class StudentService {
    private final StudentRepository studentRepository;

    @Cacheable(value = "students")
    public List<Student> getAll() {
        log.info("Getting all records");

        return studentRepository.findAll();
    }

    @Cacheable(value = "students")
    public Student getById(String id) {
        log.info("Getting record with id " + id);

        return studentRepository.findById(id).orElse(null);
    }
    @CachePut(value = "students", key = "#student.id")
    public Student create(Student student) {
        return studentRepository.save(student);
    }

    @CacheEvict("students")
    public void delete(String id) {

        studentRepository.deleteById(id);
    }

    @CacheEvict(value = "students", key="'all'")
    @CachePut(value = "students", key = "#student.id")
    public Student update(Student student) {
        return studentRepository.save(student);
    }

}
