package edu.rad.lab1.controller;
/*
  @author   max
  @project   lab1
  @class  StudentController
  @version  1.0.0
  @since 23.02.24 - 17.42
*/

import edu.rad.lab1.exception.IdentifierMismatchException;
import edu.rad.lab1.dto.Response;
import edu.rad.lab1.model.Student;
import edu.rad.lab1.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Objects;

@RestController
@RequestMapping("/api/v1/students")
@RequiredArgsConstructor
public class StudentController {

    private final StudentService studentService;

    @GetMapping
    public List<Student> fetchAll() {
        return studentService.getAll();
    }

    @GetMapping("/{id}")
    public Student fetchById(@PathVariable String id) {
        return studentService.getById(id);
    }

    @PostMapping
    public ResponseEntity<Student> insert(@RequestBody Student student) {
        return new ResponseEntity<Student>(studentService.create(student), HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(value = HttpStatus.NO_CONTENT)
    public void eraseById(@PathVariable String id) {
        studentService.delete(id);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Student> update(@RequestBody Student student, @PathVariable String id)  {

        return new ResponseEntity<Student>(studentService.update(student), HttpStatus.OK);
    }

}
