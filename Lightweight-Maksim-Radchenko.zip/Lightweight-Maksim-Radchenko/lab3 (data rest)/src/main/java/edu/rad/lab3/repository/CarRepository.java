package edu.rad.lab3.repository;
/*
  @author   max
  @project   lab3
  @class  CarRepository
  @version  1.0.0 
  @since 25.02.24 - 13.31
*/


import edu.rad.lab3.model.Car;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.stereotype.Repository;

@Repository
@RepositoryRestResource(collectionResourceRel = "cars", path = "cars")
public interface CarRepository extends MongoRepository<Car, String> {

}
