package edu.rad.lab3.seeder;
/*
  @author   max
  @project   lab3
  @class  DatabaseLoader
  @version  1.0.0 
  @since 25.02.24 - 13.32
*/

import edu.rad.lab3.model.Car;
import edu.rad.lab3.repository.CarRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
@RequiredArgsConstructor
public class DatabaseLoader implements CommandLineRunner {

    private final CarRepository carRepository;
    private List<Car> carsData = List.of(
            new Car(null, "Toyota", "RAV4", 2019),
            new Car(null, "Honda", "Civic", 1997),
            new Car(null, "Wolkswagen", "Civic", 1997)
    );

    @Override
    public void run(String... args) throws Exception {
        if (!carRepository.findAll().isEmpty()) {
            log.info("db already contains some data");
            return;
        }

        carRepository.saveAll(carsData);
        log.info("seed db with sample data");

    }
}
