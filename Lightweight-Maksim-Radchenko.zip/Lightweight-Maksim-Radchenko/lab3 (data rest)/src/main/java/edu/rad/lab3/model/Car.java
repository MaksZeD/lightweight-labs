package edu.rad.lab3.model;
/*
  @author   max
  @project   lab3
  @class  Car
  @version  1.0.0 
  @since 25.02.24 - 13.27
*/

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Car {
    @Id
    private String id;
    private String manufacturer;
    private String model;
    private int releaseDate;
}
