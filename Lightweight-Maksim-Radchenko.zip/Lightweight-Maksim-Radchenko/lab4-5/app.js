import express from "express";
import morgan from "morgan";
import carsRouter from "./routers/cars-router";
import * as path from "path";

const port = 3000;
const app = express();

const BASE_CARS_URL = '/api/v1/cars';

app.use(morgan('tiny'));
app.set('views', path.join('views'));
app.set('view engine', path.join('ejs'));

app.use(BASE_CARS_URL, carsRouter);

app.listen(port, () => {
  console.log(`App listening on port ${port}`)
})
