import express from "express";
import cars from '../data/cars.json';
import _ from 'lodash';


const carsRouter = express.Router();

carsRouter.get('/', (req, res) => {
        res.json({cars});
});

carsRouter.get('/:id', (req, res) => {
    const id = Number(req.params.id);
    const car = _.find(cars, (car) => car.id === id);

    if (car) {
        res.json(car)
    }

    res.status(404);
    res.json({ error: 'Not found' });

});

module.exports = carsRouter;
